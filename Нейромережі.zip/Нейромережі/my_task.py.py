import cv2
from PIL import Image
import numpy as np

image_path = 'face.jpg'
glasses_path = 'glasses.png'
tiara_path = 'tiara.png'

face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

img_cv = cv2.imread(image_path)
if img_cv is None:
    exit()

gray = cv2.cvtColor(img_cv, cv2.COLOR_BGR2GRAY)
faces = face_cascade.detectMultiScale(gray, 1.1, 5, minSize=(100, 100))

if len(faces) == 0:
    exit()

face_pil = Image.open(image_path).convert("RGBA")
glasses_pil = Image.open(glasses_path).convert("RGBA")
tiara_pil = Image.open(tiara_path).convert("RGBA")

for (x, y, w, h) in faces:
    def resize_acc(img_pil, target_w):
        orig_w, orig_h = img_pil.size
        target_h = int(orig_h * (target_w / orig_w))
        return img_pil.resize((target_w, target_h), Image.Resampling.LANCZOS)

    glasses_res = resize_acc(glasses_pil, int(w * 0.95))
    gw, gh = glasses_res.size
    face_pil.paste(glasses_res, (x + int((w - gw) / 2), y + int(h / 4)), glasses_res)

    tiara_res = resize_acc(tiara_pil, int(w * 0.85))
    tw, th = tiara_res.size
    tx = x + int((w - tw) / 2)
    ty = y - int(th * 0.5)
    
    face_pil.paste(tiara_res, (tx, max(0, ty)), tiara_res)
    break 

result_img = cv2.cvtColor(np.array(face_pil), cv2.COLOR_RGBA2BGRA)
cv2.imshow("Result", result_img)
cv2.waitKey(0)
cv2.destroyAllWindows()